insert into categoria values(1,'Aventura');
insert into categoria values(2,'Romance');
insert into categoria values(3,'Com�dia');
insert into categoria values(4,'A��o');
insert into categoria values(5,'Suspense');
insert into categoria values(6,'Drama');

