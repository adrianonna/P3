insert into filme values(1,'Encontro Explosivo',2010,134,4,1);
insert into filme values(2,'O Besouro Verde',2010,155,1,1);
insert into filme values(3,'Comer, Rezar, Amar',2010,177,2,1);
insert into filme values(4,'Bastardos Ingl�rios',2009,122,4,1);
insert into filme values(5,'Sr e Sra Smith',2005,119,4,2);
insert into filme values(6,'O Fim da Escurid�o',2009,100,6,1);
