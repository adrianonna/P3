insert into artista values(1,'Cameron Diaz',null,'USA','15/07/75');
insert into artista values(2,'Julia Roberts',null,'USA','20/08/67');
insert into artista values(3,'Brad Pitt',null,null,'05/03/70');
insert into artista values(4,'Mel Gibson',null,null,'06/04/59');
insert into artista values(5,'Russel Crowe',null,'USA','06/06/62');
insert into artista values(6,'Tom Cruise',null,'USA','10/09/64');
insert into artista values(7,'Antonio Fagundes','Rio de Janeiro','Brasil','12/10/58');