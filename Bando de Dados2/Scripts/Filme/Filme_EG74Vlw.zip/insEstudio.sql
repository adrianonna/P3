insert into estudio values(1,'Paramount');
insert into estudio values(2,'Disney');
insert into estudio values(3,'Universal');