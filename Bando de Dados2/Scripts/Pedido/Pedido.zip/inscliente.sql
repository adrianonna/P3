insert into cliente values(1,'Claudia Dias',null,null, '564325','786534','Recife','PE');
insert into cliente values(2,'Joaquim Moraes','Epitacio Pessoa, 123','32425643', '500925','789004','Joao Pessoa','PB');
insert into cliente values(3,'Janaina Rodrigues','Rui Carneiro, 342',null, '764325','386534','Joao Pessoa','PB');
insert into cliente values(4,'Maria Portela','Boa Viagem, 345','76435678', null,null,'Recife','PE');
insert into cliente values(5,'Ana Moura','Nego, 321','32465432', '87325','780978','Joao Pessoa','PB');
insert into cliente values(6,'Cassandra Doura',null,null, '786525','79876','Recife','PE');
insert into cliente values(7,'Cicero Novaes',null,null, '123525','432534','Natal','RN');
insert into cliente values(8,'Marcos Araruna','Sergipe,267','43265432', '900325','800534','Joao Pessoa','PB');
