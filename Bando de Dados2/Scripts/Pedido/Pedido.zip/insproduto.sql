insert into produto values(25,'Queijo', 12.00, 'KG');
insert into produto values(22,'Chocolate', 4.12, 'G');
insert into produto values(15,'Leite', 5.00, 'L');
insert into produto values(45,'Linho', 20.00, 'M');
insert into produto values(44,'Feijao', 4.00, 'KG');
insert into produto values(10,'Acucar', 1.00, 'KG');


