insert into vendedor values(1,'Juan Gomes', '28/07/1978', 2300.80,'C');
insert into vendedor values(2,'Joao Peregrino', '20/05/1970', 3300.80,'B');
insert into vendedor values(3,'Carla Gomes', '12/02/1968', 5300.80,'A');
insert into vendedor values(4,'Josefa Cirino', '23/08/1980', 2300.80,'C');
insert into vendedor values(5,'Ariane Dutra', '28/09/1983', 3300.80,'B');

