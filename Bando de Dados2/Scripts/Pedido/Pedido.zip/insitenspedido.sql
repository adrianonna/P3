insert into itenspedido values(205,25, 35);
insert into itenspedido values(205,22, 30);
insert into itenspedido values(205,15, 10);
insert into itenspedido values(120,45, 35);
insert into itenspedido values(120,44, 10);
insert into itenspedido values(123,45, 35);
insert into itenspedido values(123,10, 10);





