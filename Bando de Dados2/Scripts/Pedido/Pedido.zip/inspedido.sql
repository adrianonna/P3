insert into pedido values(205,23, '12/09/2009', 1,1);
insert into pedido values(120,10, '21/09/2009', 2,1);
insert into pedido values(222,5, '25/09/2009', 3,4);
insert into pedido values(123,2, '28/09/2009', 4,2);
insert into pedido values(201,3, '28/09/2009', 5,3);
insert into pedido values(204,3, '26/09/2009', 5,2);


